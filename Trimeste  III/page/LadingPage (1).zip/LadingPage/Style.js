const btntoggle=document.querySelector(".toggle-btn");
btntoggle.addEventListener("Click",function(){
document.getElementById(sidebar).classList.toggle("active");
});